﻿namespace ProjetoDDD.MVC.Models.IntegrationModel.DDD.Models
{
    public class Experiencia
    {
        public string Tecnologia { get; set; }
        public int TempoExperiencia { get; set; }
        public string DetalheExperiencia { get; set; }
    }
}