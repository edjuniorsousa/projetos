﻿using ProjetoDDD.Domain.Entities;

namespace ProjetoDDD.Domain.Interfaces.Services
{
    public interface IExperienciaService : IServiceBase<Experiencia>
    {
    }
}
