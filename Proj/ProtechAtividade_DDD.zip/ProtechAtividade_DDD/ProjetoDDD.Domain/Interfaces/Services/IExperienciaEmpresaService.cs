﻿using ProjetoDDD.Domain.Entities;

namespace ProjetoDDD.Domain.Interfaces.Services
{
    public interface IExperienciaEmpresaService : IServiceBase<ExperienciaEmpresa>
    {
    }
}
