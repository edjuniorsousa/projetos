﻿using ProjetoDDD.Domain.Entities;

namespace ProjetoDDD.Domain.Interfaces.Services
{
    public interface IFormacaoService : IServiceBase<Formacao>
    {
    }
}
