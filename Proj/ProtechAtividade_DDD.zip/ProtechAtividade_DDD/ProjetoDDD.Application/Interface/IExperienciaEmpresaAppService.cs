﻿using ProjetoDDD.Domain.Entities;

namespace ProjetoDDD.Application.Interface
{
    public interface IExperienciaEmpresaAppService : IAppServiceBase<ExperienciaEmpresa>
    {
    }
}
