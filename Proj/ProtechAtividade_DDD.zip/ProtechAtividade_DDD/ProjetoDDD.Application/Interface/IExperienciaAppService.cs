﻿using ProjetoDDD.Domain.Entities;

namespace ProjetoDDD.Application.Interface
{
    public interface IExperienciaAppService : IAppServiceBase<Experiencia>
    {
    }
}
