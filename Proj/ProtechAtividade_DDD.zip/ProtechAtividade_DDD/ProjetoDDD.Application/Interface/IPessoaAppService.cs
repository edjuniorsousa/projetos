﻿using ProjetoDDD.Domain.Entities;

namespace ProjetoDDD.Application.Interface
{
    public interface IPessoaAppService : IAppServiceBase<Pessoa>
    {
    }
}