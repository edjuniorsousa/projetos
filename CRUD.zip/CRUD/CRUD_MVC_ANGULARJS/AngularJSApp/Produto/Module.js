﻿var ProdutoApp;
var CompraApp;

(function () {
    ProdutoApp = angular.module('produtos', []);
    CompraApp = angular.module('compras', []);
})();